<footer class="main-footer">
	
	<strong>Copyright &copy; 2019 <a href="https://www.compartiendocodigos.net/" target="_blank">Compartiendo Códigos</a>.</strong>

	Todos los derechos reservados.


</footer>